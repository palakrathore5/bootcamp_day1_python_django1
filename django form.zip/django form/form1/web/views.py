from django.shortcuts import render,HttpResponse


def form(request):
    return render(request, 'web/form.html')
